
// images = document.getElementsByClassName('img1');
// console.log(images);
// h1_tag = document.getElementById('hair');
// aboutus = document.getElementById('btn1');
// call = document.getElementById('btn2');
// index = 0;
// function slider()
// {
//     for(i=0;i<images.length;i++)
//     {
//         images[i].style.opacity = "0";
//         images[i].style.transform = "scale(1.0)";
//         images[i].style.transition = "10s";
//     }
    
//     images[index].style.opacity = "1";
//     images[index].style.transform = "scale(1.1)";
//     images[index].style.transition = "10s";
//     index++;

//     if(index==2)
//     {
//         index=0;
//     }

//     if(images[0].style.opacity == "1")
//     {
//         h1_tag.style.visibility = "hidden";
//     }
//     else
//     {
//         h1_tag.style.visibility = "visible";
//     }

//     setTimeout("slider()",10000);
// }

// background1 = document.getElementById('bg-1')
// background2 = document.getElementById('bg-2')
// hairstyle1 = document.getElementById('h11');
// para1 = document.getElementById('para1');
// button1 = document.getElementById('btn11');
// button2 = document.getElementById('btn21');

// hairstyle2 = document.getElementById('h12');
// para2 = document.getElementById('para2');
// button3 = document.getElementById('btn12');
// button4 = document.getElementById('btn22');

// function effect1()
// {
    
//     if(background1.style.visibility == "hidden" )
//     {
//         background1.style.visibility = "visible";
//         background2.style.visibility = "hidden";
//         // background1.style.height = "100vh";
//         // background1.style.width = "100%";
//         background1.style.background = 'url("https://cutstyle.true-emotions.studio/dark-beard/wp-content/uploads/sites/4/2019/03/beard4.jpg")';
//         background1.style.backgroundSize = "cover";
//         background1.style.backgroundPosition = "10px -140px";
//         background2.style.backgroundPosition = "0px -140px";
//         background1.style.zIndex = "1";
//         background2.style.zIndex = "0";
//         background1.style.transition = "10s"; 
//         hairstyle1.style.opacity = "1";
//         hairstyle1.style.transition = "10s ease-in";
//         hairstyle1.style.transitionDelay = "2s";
//         para1.style.display = "block";
//         button1.style.opacity = "1";
//         button2.style.opacity = "1";
//         hairstyle2.style.opacity = "0";
//         hairstyle2.style.transition = "0s";
//         para2.style.display = "none";
//         button3.style.opacity = "0";
//         button4.style.opacity = "0";
//         button1.style.transform = "translateY(0px)";
//         button1.style.transition = "transform 2s, opacity 1s";
//         button2.style.transform = "translateY(0px)";
//         button2.style.transition = "transform 3s, opacity 1s";
//         // button3.style.transform = "translateY(80px)";
//         // button4.style.transform = "translateY(80px)";
//         button3.style.transition = "opacity 0s, transform 0s";
//         button4.style.transition = "opacity 0s, transform 0s";
//     }
//     else
//     {
//         background2.style.visibility = "visible";
//         background1.style.visibility = "hidden";
//         // background2.style.height = "100vh";
//         // background2.style.width = "100%";
//         background2.style.background = 'url("https://cutstyle.true-emotions.studio/dark-beard/wp-content/uploads/sites/4/2019/03/beard6.jpg")';
//         background2.style.backgroundSize = "cover";
//         background2.style.backgroundPosition = "10px -140px";
//         background1.style.backgroundPosition = "0px -140px";
//         background1.style.zIndex = "0";
//         background2.style.zIndex = "1";
//         background2.style.transition = "10s";
//         hairstyle2.style.opacity = "1";
//         hairstyle2.style.transition = "10s ease-in";
//         hairstyle2.style.transitionDelay = "2s";
//         para2.style.display = "block";
//         button3.style.opacity = "1";
//         button4.style.opacity = "1";
//         hairstyle1.style.opacity = "0";
//         hairstyle1.style.transition = "0s";
//         para1.style.display = "none";
//         button1.style.opacity = "0";
//         button2.style.opacity = "0";
//         button3.style.transform = "translateY(0px)";
//         button3.style.transition = "transform 2s, opacity 1s";
//         button4.style.transform = "translateY(0px)";
//         button4.style.transition = "transform 3s, opacity 1s";
//         // button1.style.transform = "translateY(80px)";
//         // button2.style.transform = "translateY(80px)";
//         button1.style.transition = "0s";
//         button2.style.transition = "0s";
//     }
    
//     setTimeout("effect1()",10000);
// }

// effect1();





background1 = document.getElementById('bg-1');
background2 = document.getElementById('bg-2');
header = document.getElementById('header');
hairstyle1 = document.getElementById('h11');
para1 = document.getElementById('para1');
// button1 = document.getElementById('btn11');
// button2 = document.getElementById('btn21');

hairstyle2 = document.getElementById('h12');
para2 = document.getElementById('para2');
// button3 = document.getElementById('btn12');
// button4 = document.getElementById('btn22');

// background1.addEventListener("load", effect2);

function effect2() {
    if (background1.classList.contains("show")) {
        background1.classList.remove("show");
        background1.classList.add("hidden");

        background2.classList.remove("hidden");
        background2.classList.add("show");
    } else {
        background2.classList.remove("show");
        background2.classList.add("hidden");

        background1.classList.remove("hidden");
        background1.classList.add("show");
    }
    
    setTimeout(effect2, 5000);
}
effect2();


function swapParagraphs() {
    let para1 = document.getElementById("para1");
    let para2 = document.getElementById("para2");

    if (para1.classList.contains("visible")) {
        para1.classList.remove("visible");
        para1.classList.add("hidden2");

        para2.classList.remove("hidden2");
        para2.classList.add("visible");
    } else {
        para2.classList.remove("visible");
        para2.classList.add("hidden2");

        para1.classList.remove("hidden2");
        para1.classList.add("visible");
    }
}

setInterval(swapParagraphs, 5000); // Swap every 3 seconds
swapParagraphs();

// function buttonupdown() {
//     let button1 = document.getElementById('btn11');
//     let button2 = document.getElementById('btn21');
//     let button3 = document.getElementById('btn12');
//     let button4 = document.getElementById('btn22');

//     if (button1.style.transform === "translate(0px, 80px)") {
//         // Move first set up
//         button1.classList.remove("button-down");
//         button1.classList.add("button-up");

//         button2.classList.remove("button-down");
//         button2.classList.add("button-up");

//         // Move second set down
//         button3.classList.remove("button-up");
//         button3.classList.add("button-down");

//         button4.classList.remove("button-up");
//         button4.classList.add("button-down");
//     } else {
//         // Move first set down
//         button1.classList.remove("button-up");
//         button1.classList.add("button-down");

//         button2.classList.remove("button-up");
//         button2.classList.add("button-down");

//         // Move second set up
//         button3.classList.remove("button-down");
//         button3.classList.add("button-up");

//         button4.classList.remove("button-down");
//         button4.classList.add("button-up");
//     }
// }

// // Run every 2 seconds
// setInterval(buttonupdown, 2000);
// buttonupdown();


function buttonUpDown()
{
    let button1 = document.getElementById('btn11');
    let button2 = document.getElementById('btn21');
    let button3 = document.getElementById('btn12');
    let button4 = document.getElementById('btn22');

    if(button1.style.transform == "translate(0px, 0px)")
    {
        button1.style.opacity = "0";
        button1.style.transform = "translate(0px, 80px)";
        button2.style.opacity = "0";
        button2.style.transform = "translate(0px, 80px)";
        
        button3.style.transform = "translate(0px, 0px)";
        button3.style.opacity = "1"
        button3.style.transition = "transform 2s";
        button4.style.transform = "translate(0px, 0px)";
        button4.style.opacity = "1";
        button4.style.transition = "transform 3s";

    }
    else
    {
        button1.style.transform = "translate(0px, 0px)";
        button1.style.opacity = "1";
        button1.style.transition = "transform 2s";
        button2.style.transform = "translate(0px, 0px)";
        button2.style.opacity = "1";
        button2.style.transition = "transform 3s";

        button3.style.transform = "translate(0px, 80px)";
        button3.style.opacity = "0";
        button4.style.transform = "translate(0px, 80px)";
        button4.style.opacity = "0";
    }
}
setInterval(buttonUpDown, 5000);
buttonUpDown();



let select2 = document.getElementById('select2');
let option2 = document.getElementById('option2');

select2.addEventListener("click",myFunction1);

function myFunction1()
{
    if(option2.style.display === "none")
    {
        option2.style.display = "block";
    }
    else
    {
        option2.style.display = "none";
    }
}

myFunction1();




let select3 = document.getElementById('select3');
let option3 = document.getElementById('option3');

select3.addEventListener("click",myFunction2);

function myFunction2()
{
    if(option3.style.display === "none")
    {
        option3.style.display = "block";
    }
    else
    {
        option3.style.display = "none";
    }
}

myFunction2();






let select4 = document.getElementById('select4');
let option4 = document.getElementById('option4');

select4.addEventListener("click",myFunction3);

function myFunction3()
{
    if(option4.style.display === "none")
    {
        option4.style.display = "block";
    }
    else
    {
        option4.style.display = "none";
    }
}

myFunction3();

